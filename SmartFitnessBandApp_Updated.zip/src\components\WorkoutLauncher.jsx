import React from 'react';
import { useFitness } from '../context/FitnessContext';
import {
  Footprints,
  Bike,
  Navigation,
  Flame,
  Dumbbell,
  Waves,
  Smile,
  Play,
  Pause,
  Square,
  Activity,
  Timer,
  Heart,
  Zap,
  MapPin
} from 'lucide-react';
import { initialFitnessState } from '../data/mockFitnessData';

const iconMap = {
  Footprints,
  Bike,
  Navigation,
  Flame,
  Dumbbell,
  Waves,
  Smile
};

export const WorkoutLauncher = () => {
  const {
    activeWorkout,
    startWorkout,
    pauseWorkout,
    finishWorkout
  } = useFitness();

  const workouts = initialFitnessState.workouts;

  // Format seconds into MM:SS or HH:MM:SS
  const formatTime = (totalSeconds) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    if (hrs > 0) {
      return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      
      {/* Workout Grid Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div>
          <h3 className="text-lg font-black text-black flex items-center gap-2">
            <Flame className="w-5 h-5 text-rose-500" />
            Quick Workout Launcher
          </h3>
          <p className="text-xs text-black/80 font-medium">Launch real-time band workout session with continuous sensor telemetry</p>
        </div>
      </div>

      {/* Workout Type Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {workouts.map((w) => {
          const IconComponent = iconMap[w.icon] || Activity;

          return (
            <div
              key={w.id}
              className="glass-card-interactive rounded-2xl p-5 flex flex-col justify-between group relative overflow-hidden"
            >
              {/* Background gradient hint */}
              <div
                className="absolute top-0 right-0 w-32 h-32 rounded-full blur-2xl pointer-events-none opacity-20 group-hover:opacity-40 transition-opacity"
                style={{ background: w.bgGlow }}
              ></div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl bg-gradient-to-tr ${w.color} text-white shadow-md shadow-emerald-500/10`}>
                    <IconComponent className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <span className="text-[10px] text-black font-mono bg-slate-200 px-2 py-0.5 rounded-full border border-slate-300 font-extrabold">
                    {w.calRate}
                  </span>
                </div>

                <h4 className="text-base font-black text-black group-hover:text-emerald-800 transition-colors">
                  {w.name}
                </h4>
                <p className="text-xs text-black/80 font-medium mt-1">Status: <strong className="text-black font-black">{w.avgPace}</strong></p>
              </div>

              <button
                onClick={() => startWorkout(w)}
                className="mt-5 w-full py-2.5 bg-black hover:bg-emerald-600 text-white rounded-xl text-xs font-black flex items-center justify-center space-x-2 transition-all active:scale-95 shadow-sm"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Start Workout</span>
              </button>
            </div>
          );
        })}
      </div>

      {/* Active Workout Live Modal HUD */}
      {activeWorkout && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xl">
          <div className="bg-[#121826] border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-xl w-full shadow-2xl relative overflow-hidden text-white">
            
            {/* Ambient workout glow */}
            <div className="absolute -top-20 -right-20 w-60 h-60 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none"></div>

            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/30">
                  <Flame className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-xl font-extrabold text-white">{activeWorkout.name}</h3>
                    <span className="flex h-2.5 w-2.5 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                    </span>
                  </div>
                  <p className="text-xs text-emerald-400 font-semibold mt-0.5">Live Workout Active on Band</p>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-slate-400 uppercase font-mono">Status</span>
                <p className="text-xs font-bold text-slate-200">
                  {activeWorkout.isPaused ? '⏸️ PAUSED' : '⚡ RECORDING'}
                </p>
              </div>
            </div>

            {/* Huge Timer HUD */}
            <div className="text-center my-6">
              <span className="text-xs text-slate-400 uppercase font-mono tracking-widest">Elapsed Time</span>
              <div className="text-6xl sm:text-7xl font-extrabold text-white font-mono tracking-tight mt-1">
                {formatTime(activeWorkout.elapsedSeconds)}
              </div>
            </div>

            {/* Live Telemetry Grid */}
            <div className="grid grid-cols-3 gap-3 my-6">
              
              {/* Live Heart Rate */}
              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 text-center">
                <div className="flex items-center justify-center space-x-1 text-rose-400 mb-1">
                  <Heart className="w-4 h-4 fill-rose-500/40 animate-pulse" />
                  <span className="text-[10px] font-bold uppercase">Live BPM</span>
                </div>
                <div className="text-2xl sm:text-3xl font-extrabold text-white">
                  {activeWorkout.heartRate}
                </div>
                <span className="text-[10px] text-rose-400 font-semibold">Cardio Zone</span>
              </div>

              {/* Live Calories */}
              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 text-center">
                <div className="flex items-center justify-center space-x-1 text-amber-400 mb-1">
                  <Flame className="w-4 h-4" />
                  <span className="text-[10px] font-bold uppercase">Calories</span>
                </div>
                <div className="text-2xl sm:text-3xl font-extrabold text-white">
                  {Math.round(activeWorkout.activeCalories)}
                </div>
                <span className="text-[10px] text-amber-400 font-semibold">kcal burned</span>
              </div>

              {/* Live Distance */}
              <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 text-center">
                <div className="flex items-center justify-center space-x-1 text-cyan-400 mb-1">
                  <MapPin className="w-4 h-4" />
                  <span className="text-[10px] font-bold uppercase">Distance</span>
                </div>
                <div className="text-2xl sm:text-3xl font-extrabold text-white">
                  {activeWorkout.distanceKm.toFixed(2)}
                </div>
                <span className="text-[10px] text-cyan-400 font-semibold">km</span>
              </div>

            </div>

            {/* GPS Simulated Route animation banner */}
            <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 mb-6 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span className="text-slate-300">Connected GPS: Satellite Lock (Accuracy: ±2.1m)</span>
              </div>
              <span className="text-emerald-400 font-mono font-bold">5'14"/km</span>
            </div>

            {/* Workout Control Actions */}
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={pauseWorkout}
                className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-2xl flex items-center justify-center space-x-2 border border-slate-700 transition-all active:scale-95"
              >
                {activeWorkout.isPaused ? (
                  <>
                    <Play className="w-4 h-4 fill-current text-emerald-400" />
                    <span>Resume</span>
                  </>
                ) : (
                  <>
                    <Pause className="w-4 h-4 text-amber-400" />
                    <span>Pause</span>
                  </>
                )}
              </button>

              <button
                onClick={finishWorkout}
                className="py-3 px-4 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold rounded-2xl flex items-center justify-center space-x-2 shadow-lg shadow-rose-600/30 transition-all active:scale-95"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>Finish & Save</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
