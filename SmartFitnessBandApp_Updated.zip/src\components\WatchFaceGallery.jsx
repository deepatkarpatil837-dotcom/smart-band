import React, { useState } from 'react';
import { useFitness } from '../context/FitnessContext';
import { Watch, Check, Sparkles, Sliders, Sun, Clock, Eye } from 'lucide-react';

export const WatchFaceGallery = () => {
  const { watchFaces, selectWatchFace, metrics, device } = useFitness();
  const [alwaysOn, setAlwaysOn] = useState(false);
  const [raiseToWake, setRaiseToWake] = useState(true);
  const [brightness, setBrightness] = useState(80);

  const activeFace = watchFaces.find((f) => f.active) || watchFaces[0];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div>
        <h3 className="text-lg font-black text-black flex items-center gap-2">
          <Watch className="w-5 h-5 text-emerald-700" />
          Band Customizer & Watch Faces
        </h3>
        <p className="text-xs text-black/80 font-medium">Personalize AMOLED display faces and on-wrist display gestures</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Live Band Mockup Display */}
        <div className="lg:col-span-5 glass-card rounded-2xl p-6 shadow-md flex flex-col items-center justify-center text-center">
          <span className="text-xs font-black text-black uppercase tracking-widest mb-4">Live Wrist Screen Preview</span>

          {/* 3D Smart Band Form Factor */}
          <div className="relative w-44 h-80 bg-[#0c1017] rounded-[38px] p-3.5 border-4 border-slate-700 shadow-2xl flex flex-col justify-between overflow-hidden">
            
            {/* Band Strap Connectors */}
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-24 h-3 bg-slate-800 rounded-t-lg"></div>
            <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-24 h-3 bg-slate-800 rounded-b-lg"></div>

            {/* AMOLED Screen Content */}
            <div className="w-full h-full rounded-[26px] bg-[#000] p-4 flex flex-col justify-between relative overflow-hidden border border-slate-900 text-white">
              
              {/* Top Row: Battery & Bluetooth */}
              <div className="flex items-center justify-between text-[9px] text-slate-400 font-mono">
                <span className="text-emerald-400 font-bold">10:42 AM</span>
                <span>{device.batteryLevel}% 🔋</span>
              </div>

              {/* Center Watch Face Theme */}
              <div className="text-center my-auto">
                {activeFace.id === 'neon-pulse' && (
                  <div className="space-y-1">
                    <span className="text-3xl font-extrabold text-emerald-400 font-mono tracking-tight animate-pulse">
                      10:42
                    </span>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">THU, AUG 27</p>
                    <div className="flex items-center justify-center gap-1.5 text-xs text-rose-400 font-bold mt-2">
                      <span>❤️ {metrics.heartRate.current}</span>
                      <span className="text-slate-600">|</span>
                      <span>👟 {metrics.steps.current}</span>
                    </div>
                  </div>
                )}

                {activeFace.id === 'chrono-metric' && (
                  <div className="space-y-2">
                    <div className="w-16 h-16 rounded-full border-4 border-rose-500 border-t-emerald-400 border-l-cyan-400 mx-auto flex items-center justify-center">
                      <span className="text-xs font-black text-white">84%</span>
                    </div>
                    <span className="text-lg font-bold text-white font-mono block">10:42:30</span>
                    <span className="text-[9px] text-slate-400">CAL {metrics.calories.active} kcal</span>
                  </div>
                )}

                {activeFace.id === 'cyber-orbit' && (
                  <div className="space-y-1">
                    <div className="text-[10px] font-mono text-cyan-400">ORBIT TELEMETRY</div>
                    <span className="text-2xl font-black text-cyan-300 font-mono tracking-widest block">10:42</span>
                    <div className="text-[9px] text-slate-300 bg-cyan-950/60 rounded px-1 py-0.5 border border-cyan-800/60">
                      SpO2 {metrics.spo2.current}% • HR {metrics.heartRate.current}
                    </div>
                  </div>
                )}

                {activeFace.id === 'zen-gradient' && (
                  <div className="space-y-2">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 blur-sm mx-auto opacity-70"></div>
                    <span className="text-2xl font-light text-white tracking-widest block">10:42</span>
                    <p className="text-[10px] text-purple-300 italic">Breathe & Move</p>
                  </div>
                )}
              </div>

              {/* Bottom Mini Rings */}
              <div className="w-full bg-slate-900/90 h-1.5 rounded-full overflow-hidden flex">
                <div className="bg-emerald-500 h-full w-[84%]"></div>
                <div className="bg-rose-500 h-full w-[85%]"></div>
              </div>

            </div>

          </div>

          <p className="text-xs text-black font-black mt-4">Active Face: <span className="text-emerald-800 font-black">{activeFace.name}</span></p>
        </div>

        {/* Watch Face Catalog & Hardware Display Settings */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Watch Face Selection */}
          <div className="glass-card rounded-2xl p-6 shadow-md">
            <h4 className="text-sm font-black text-black mb-3">Select Watch Face</h4>
            <div className="grid grid-cols-2 gap-3">
              {watchFaces.map((face) => (
                <div
                  key={face.id}
                  onClick={() => selectWatchFace(face.id)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col justify-between shadow-xs ${
                    face.active
                      ? 'bg-emerald-100/90 border-emerald-500 text-black shadow-md shadow-emerald-500/10'
                      : 'bg-white/90 border-amber-900/10 text-black hover:border-amber-900/25'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: face.previewColor }}></div>
                    {face.active && (
                      <span className="flex items-center text-emerald-800 text-[10px] font-black">
                        <Check className="w-3 h-3 mr-0.5" /> Installed
                      </span>
                    )}
                  </div>
                  <div>
                    <h5 className="text-xs font-black text-black">{face.name}</h5>
                    <p className="text-[10px] text-black/80 font-semibold">{face.style}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Band Screen Hardware Toggles */}
          <div className="glass-card rounded-2xl p-6 shadow-md space-y-4">
            <h4 className="text-sm font-black text-black">AMOLED Display Settings</h4>

            {/* Always-On Display */}
            <div className="flex items-center justify-between p-3 bg-white/90 rounded-xl border border-amber-900/10 shadow-xs">
              <div className="flex items-center space-x-3">
                <Clock className="w-4 h-4 text-purple-700" />
                <div>
                  <h5 className="text-xs font-black text-black">Always-On Display (AOD)</h5>
                  <p className="text-[10px] text-black/80 font-medium">Keep essential clock face visible when wrist is lowered</p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={alwaysOn}
                onChange={(e) => setAlwaysOn(e.target.checked)}
                className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
              />
            </div>

            {/* Raise to Wake */}
            <div className="flex items-center justify-between p-3 bg-white/90 rounded-xl border border-amber-900/10 shadow-xs">
              <div className="flex items-center space-x-3">
                <Eye className="w-4 h-4 text-cyan-700" />
                <div>
                  <h5 className="text-xs font-black text-black">Raise Wrist to Wake</h5>
                  <p className="text-[10px] text-black/80 font-medium">Automatically activate display on wrist motion</p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={raiseToWake}
                onChange={(e) => setRaiseToWake(e.target.checked)}
                className="w-4 h-4 accent-emerald-600 rounded cursor-pointer"
              />
            </div>

            {/* Screen Brightness Slider */}
            <div className="p-3 bg-white/90 rounded-xl border border-amber-900/10 space-y-2 shadow-xs">
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 text-black font-black">
                  <Sun className="w-4 h-4 text-amber-600" /> Display Brightness
                </span>
                <span className="text-black font-mono font-black">{brightness}%</span>
              </div>
              <input
                type="range"
                min="20"
                max="100"
                value={brightness}
                onChange={(e) => setBrightness(e.target.value)}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
