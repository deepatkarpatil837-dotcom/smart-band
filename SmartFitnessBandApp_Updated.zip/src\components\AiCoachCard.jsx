import React from 'react';
import { useFitness } from '../context/FitnessContext';
import { initialFitnessState } from '../data/mockFitnessData';
import { Sparkles, Trophy, Flame, CheckCircle2, ChevronRight, Award } from 'lucide-react';

export const AiCoachCard = () => {
  const { metrics } = useFitness();
  const insights = initialFitnessState.aiInsights;
  const weeklyHistory = initialFitnessState.weeklyHistory;

  return (
    <div className="space-y-6">
      
      {/* AI Health Coach Banner */}
      <div className="glass-card rounded-2xl p-6 shadow-md relative overflow-hidden">
        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2.5 bg-gradient-to-tr from-purple-600 to-indigo-600 text-white rounded-xl shadow-md shadow-purple-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-black flex items-center gap-2">
              FitPulse AI Health Coach
              <span className="text-[10px] bg-purple-100 text-black border border-purple-300 px-2 py-0.5 rounded-full font-black">
                Neural Engine
              </span>
            </h3>
            <p className="text-xs text-black/80 font-medium">Personalized recovery & training recommendations</p>
          </div>
        </div>

        {/* Dynamic Insight Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {insights.map((insight) => (
            <div
              key={insight.id}
              className="bg-white/95 p-4 rounded-xl border border-amber-900/10 hover:border-purple-500/30 transition-all flex flex-col justify-between shadow-xs"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] font-black tracking-wider mb-2">
                  <span className={`px-2 py-0.5 rounded font-black ${
                    insight.accent === 'emerald' ? 'bg-emerald-100 text-black border border-emerald-300' :
                    insight.accent === 'cyan' ? 'bg-cyan-100 text-black border border-cyan-300' :
                    'bg-blue-100 text-black border border-blue-300'
                  }`}>
                    {insight.tag}
                  </span>
                  <span className="text-black font-mono font-bold">{insight.time}</span>
                </div>
                <h4 className="text-xs font-black text-black mb-1.5 leading-snug">{insight.title}</h4>
                <p className="text-xs text-black/80 font-medium leading-relaxed">{insight.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Weekly History & Streak Progression */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Weekly Day-by-Day Activity */}
        <div className="lg:col-span-8 glass-card rounded-2xl p-6 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="text-sm font-black text-black">Weekly Performance History</h4>
              <p className="text-xs text-black/80 font-medium">Step goals and calorie burn past 7 days</p>
            </div>
            <span className="text-xs font-black text-black bg-emerald-100 px-2.5 py-1 rounded-full border border-emerald-400">
              5 of 7 Goals Met (71%)
            </span>
          </div>

          <div className="grid grid-cols-7 gap-2 pt-2">
            {weeklyHistory.map((day, idx) => {
              const heightPct = Math.min(100, Math.round((day.steps / 15000) * 100));
              const isToday = idx === 6;

              return (
                <div key={idx} className="bg-white/90 p-3 rounded-xl border border-amber-900/10 flex flex-col items-center justify-between text-center shadow-xs">
                  <span className="text-[11px] font-black text-black mb-2">{day.day.split(' ')[0]}</span>
                  
                  {/* Vertical mini bar */}
                  <div className="w-full bg-slate-200 h-24 rounded-lg p-1 flex items-end justify-center my-1 border border-slate-300">
                    <div
                      style={{ height: `${heightPct}%` }}
                      className={`w-full rounded-md transition-all ${
                        isToday ? 'bg-gradient-to-t from-emerald-600 to-teal-500 shadow-md shadow-emerald-600/30' :
                        day.goalMet ? 'bg-emerald-500/80' : 'bg-slate-400'
                      }`}
                    ></div>
                  </div>

                  <span className="text-[10px] font-black text-black mt-1">{(day.steps / 1000).toFixed(1)}k</span>
                  <span className="text-[9px] text-black/80 font-bold">{day.sleepHours}h sleep</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Milestone Badges & Streaks */}
        <div className="lg:col-span-4 glass-card rounded-2xl p-6 shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Trophy className="w-5 h-5 text-amber-600" />
              <h4 className="text-sm font-black text-black">Milestones & Badges</h4>
            </div>

            <div className="space-y-3">
              {/* Badge 1 */}
              <div className="flex items-center space-x-3 p-2.5 bg-white/95 rounded-xl border border-amber-900/10 shadow-xs">
                <div className="p-2 bg-amber-100 text-amber-700 rounded-lg text-lg border border-amber-300">
                  🔥
                </div>
                <div>
                  <h5 className="text-xs font-black text-black">{metrics.streak.days}-Day Active Streak</h5>
                  <p className="text-[10px] text-black/80 font-medium">All 3 daily rings closed continuously</p>
                </div>
              </div>

              {/* Badge 2 */}
              <div className="flex items-center space-x-3 p-2.5 bg-white/95 rounded-xl border border-amber-900/10 shadow-xs">
                <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg text-lg border border-emerald-300">
                  👟
                </div>
                <div>
                  <h5 className="text-xs font-black text-black">100k Steps Club</h5>
                  <p className="text-[10px] text-black/80 font-medium">Passed 100,000 steps this month</p>
                </div>
              </div>

              {/* Badge 3 */}
              <div className="flex items-center space-x-3 p-2.5 bg-white/95 rounded-xl border border-amber-900/10 shadow-xs">
                <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg text-lg border border-indigo-300">
                  🌙
                </div>
                <div>
                  <h5 className="text-xs font-black text-black">Sleep Consistency Master</h5>
                  <p className="text-[10px] text-black/80 font-medium">7+ hours sleep for 5 consecutive nights</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-amber-900/10 flex items-center justify-between text-xs text-black font-bold">
            <span>Next Award: <strong className="text-black font-black">21-Day Champion</strong></span>
            <span className="text-amber-800 font-black">7 days left</span>
          </div>
        </div>

      </div>

    </div>
  );
};
