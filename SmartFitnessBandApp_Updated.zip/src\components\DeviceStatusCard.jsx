import React from 'react';
import { useFitness } from '../context/FitnessContext';
import {
  Bluetooth,
  Battery,
  BatteryCharging,
  Volume2,
  Moon,
  Droplets,
  RotateCw,
  Signal,
  CheckCircle2,
  Watch
} from 'lucide-react';

export const DeviceStatusCard = () => {
  const {
    device,
    syncBand,
    triggerFindBand,
    toggleDnd,
    toggleWaterLock
  } = useFitness();

  return (
    <div className="glass-card rounded-2xl p-5 sm:p-6 shadow-md relative overflow-hidden">
      {/* Background ambient warm glow */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16"></div>

      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
        
        {/* Band Identity & Visual Preview */}
        <div className="flex items-center space-x-4">
          {/* Smart Band Visual Icon / Pod */}
          <div className="relative">
            <div className={`w-16 h-16 rounded-2xl bg-gradient-to-b from-slate-100 to-slate-200 border ${device.findBandActive ? 'border-amber-500 animate-bounce' : 'border-amber-900/15'} flex items-center justify-center shadow-md relative`}>
              <Watch className="w-8 h-8 text-black" />
              {device.findBandActive && (
                <span className="absolute -top-2 -right-2 bg-amber-500 text-black text-[10px] font-black px-1.5 py-0.5 rounded-full animate-pulse shadow-md">
                  BEEPING!
                </span>
              )}
            </div>
            <div className="absolute -bottom-1 -right-1 bg-emerald-600 rounded-full p-1 border-2 border-white">
              <CheckCircle2 className="w-3 h-3 text-white stroke-[3]" />
            </div>
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-black text-black tracking-tight">{device.name}</h2>
              <span className="bg-emerald-100 text-black border border-emerald-400 text-[10px] font-extrabold px-2 py-0.5 rounded-full shadow-xs">
                Connected
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs text-black/80 font-medium">
              <span>Model: <strong className="text-black font-extrabold">{device.model}</strong></span>
              <span>•</span>
              <span>FW: <strong className="text-black font-extrabold">{device.firmware}</strong></span>
              <span>•</span>
              <span className="flex items-center text-black font-extrabold">
                <Signal className="w-3 h-3 text-emerald-700 mr-1" />
                {device.bluetoothRssi} dBm
              </span>
              <span>•</span>
              <span>Synced: <strong className="text-black font-black">{device.lastSynced}</strong></span>
            </div>
          </div>
        </div>

        {/* Quick Hardware Action Buttons Container */}
        <div className="flex items-center space-x-6 w-full lg:w-auto justify-between lg:justify-end border-t lg:border-t-0 pt-4 lg:pt-0 border-amber-900/10">

          <div className="flex items-center space-x-2">
            
            {/* Find Band Button */}
            <button
              onClick={triggerFindBand}
              title="Locate Smart Band (Audio/Vibration)"
              className={`p-2.5 rounded-xl border text-xs font-bold flex items-center transition-all shadow-sm ${
                device.findBandActive
                  ? 'bg-amber-500 text-black border-amber-400 animate-pulse'
                  : 'bg-white hover:bg-slate-50 text-black border-amber-900/15'
              }`}
            >
              <Volume2 className="w-4 h-4 mr-1.5 text-amber-700" />
              <span className="hidden sm:inline">Find Band</span>
            </button>

            {/* Do Not Disturb Toggle */}
            <button
              onClick={toggleDnd}
              title="Toggle Band Do Not Disturb"
              className={`p-2.5 rounded-xl border transition-all shadow-sm ${
                device.dndActive
                  ? 'bg-indigo-100 text-black border-indigo-400'
                  : 'bg-white hover:bg-slate-50 text-black border-amber-900/15'
              }`}
            >
              <Moon className="w-4 h-4" />
            </button>

            {/* Water Lock Toggle */}
            <button
              onClick={toggleWaterLock}
              title="Toggle Water Lock Mode"
              className={`p-2.5 rounded-xl border transition-all shadow-sm ${
                device.waterLock
                  ? 'bg-cyan-100 text-black border-cyan-400'
                  : 'bg-white hover:bg-slate-50 text-black border-amber-900/15'
              }`}
            >
              <Droplets className="w-4 h-4" />
            </button>

            {/* Sync Now */}
            <button
              onClick={syncBand}
              disabled={device.isSyncing}
              title="Force Refresh Data from Band"
              className="p-2.5 bg-emerald-600 hover:bg-emerald-500 text-black font-extrabold rounded-xl shadow-md shadow-emerald-600/20 active:scale-95 transition-all disabled:opacity-50"
            >
              <RotateCw className={`w-4 h-4 ${device.isSyncing ? 'animate-spin' : ''}`} />
            </button>

          </div>

        </div>

      </div>
    </div>
  );
};
