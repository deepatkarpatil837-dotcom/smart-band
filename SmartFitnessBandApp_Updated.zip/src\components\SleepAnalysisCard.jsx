import React from 'react';
import { useFitness } from '../context/FitnessContext';
import { Moon, Sparkles, Bed, Sunrise, Sunset, ShieldCheck } from 'lucide-react';

export const SleepAnalysisCard = () => {
  const { metrics } = useFitness();
  const sleep = metrics.sleep;

  return (
    <div className="glass-card rounded-2xl p-6 shadow-md">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl border border-indigo-200">
            <Moon className="w-5 h-5 fill-indigo-500/20" />
          </div>
          <div>
            <h3 className="text-base font-black text-black">Sleep & Recovery</h3>
            <p className="text-xs text-black/80 font-medium">Sleep cycle & hypnogram tracking</p>
          </div>
        </div>

        <div className="flex items-center space-x-1.5 bg-indigo-100 border border-indigo-300 px-3 py-1 rounded-full text-black text-xs font-black shadow-xs">
          <Sparkles className="w-3.5 h-3.5 text-indigo-700" />
          <span>Score: {sleep.score} / 100</span>
        </div>
      </div>

      {/* Primary Metrics: Duration & Times */}
      <div className="grid grid-cols-1 gap-4 my-4">
        
        <div className="bg-white/95 p-3.5 rounded-xl border border-amber-900/10 flex items-center space-x-3 shadow-xs">
          <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200">
            <Bed className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-black font-bold uppercase">Total Duration</span>
            <p className="text-lg font-black text-black">{sleep.totalHours} <span className="text-xs font-bold text-black/80">hours</span></p>
          </div>
        </div>

      </div>

      {/* Sleep Stages Multi-Bar */}
      <div className="space-y-3 mt-5">
        <div className="flex items-center justify-between text-xs">
          <span className="font-black text-black">Sleep Stages Breakdown</span>
          <span className="text-emerald-800 font-black flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            Efficiency: {sleep.efficiency}
          </span>
        </div>

        {/* Visual Multi-Segment Bar */}
        <div className="w-full h-4 bg-slate-200 rounded-full flex overflow-hidden p-0.5 border border-slate-300 shadow-inner">
          {sleep.stages.map((stage, idx) => (
            <div
              key={idx}
              title={`${stage.name}: ${stage.duration} (${stage.percent}%)`}
              style={{ width: `${stage.percent}%`, backgroundColor: stage.color }}
              className="h-full first:rounded-l-full last:rounded-r-full transition-all hover:opacity-85"
            ></div>
          ))}
        </div>

        {/* Stage Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
          {sleep.stages.map((stage, idx) => (
            <div key={idx} className="bg-white/90 p-2.5 rounded-xl border border-amber-900/10 shadow-xs">
              <div className="flex items-center space-x-1.5 mb-1">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: stage.color }}></span>
                <span className="text-[11px] font-black text-black truncate">{stage.name}</span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-xs font-black text-black">{stage.duration}</span>
                <span className="text-[10px] text-black font-extrabold">{stage.percent}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recovery Badge Note */}
      <div className="mt-5 p-3 rounded-xl bg-gradient-to-r from-indigo-50 via-purple-50 to-amber-50 border border-indigo-200 flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <span className="text-base">✨</span>
          <span className="text-black font-medium">
            Sleep HR averaged <strong className="text-black font-black">{sleep.restingHrDuringSleep} BPM</strong>. Restorative Deep + REM was <strong className="text-black font-black">53%</strong> (ideal range is 40-50%).
          </span>
        </div>
        <span className="text-indigo-900 font-black whitespace-nowrap hidden sm:inline">{sleep.rating}</span>
      </div>

    </div>
  );
};
