import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { initialFitnessState } from '../data/mockFitnessData';
import confetti from 'canvas-confetti';

const FitnessContext = createContext(null);

export const FitnessProvider = ({ children }) => {
  const [device, setDevice] = useState(initialFitnessState.device);
  const [metrics, setMetrics] = useState(initialFitnessState.metrics);
  const [hourlySteps, setHourlySteps] = useState(initialFitnessState.hourlySteps);
  const [watchFaces, setWatchFaces] = useState(initialFitnessState.watchFaces);
  const [activeWorkout, setActiveWorkout] = useState(null);
  const [activeTab, setActiveTab] = useState('overview'); // overview, workouts, telemetry, band-settings
  const [notificationToast, setNotificationToast] = useState(null);
  const [isSimulatingWalk, setIsSimulatingWalk] = useState(false);

  // Live ECG data points for canvas rendering
  const [ecgPoints, setEcgPoints] = useState(() => Array.from({ length: 60 }, (_, i) => 70 + Math.sin(i * 0.4) * 4));

  // Show a momentary banner/toast notification
  const showToast = (message, type = 'info') => {
    setNotificationToast({ message, type, id: Date.now() });
    setTimeout(() => {
      setNotificationToast((prev) => (prev?.id ? null : prev));
    }, 4000);
  };

  // Sync with Smart Band Simulation
  const syncBand = () => {
    if (device.isSyncing) return;
    setDevice((prev) => ({ ...prev, isSyncing: true }));
    showToast("Syncing telemetry with FitPulse Ultra Band...", "sync");

    setTimeout(() => {
      const addedSteps = Math.floor(Math.random() * 45) + 10;
      setMetrics((prev) => {
        const newSteps = prev.steps.current + addedSteps;
        const newCalories = prev.calories.active + Math.round(addedSteps * 0.042);
        return {
          ...prev,
          steps: {
            ...prev.steps,
            current: newSteps,
            distanceKm: Number((newSteps * 0.00075).toFixed(2)),
          },
          calories: {
            ...prev.calories,
            active: newCalories,
          },
        };
      });

      setDevice((prev) => ({
        ...prev,
        isSyncing: false,
        lastSynced: "Just now",
        batteryLevel: Math.max(15, prev.batteryLevel - (Math.random() > 0.8 ? 1 : 0)),
      }));

      showToast("Band synced successfully! All sensors updated.", "success");
    }, 1800);
  };

  // Add steps manually or via simulation
  const addSteps = (amount = 100) => {
    setMetrics((prev) => {
      const newSteps = prev.steps.current + amount;
      const newDistance = Number((newSteps * 0.00075).toFixed(2));
      const addedCal = Math.round(amount * 0.044);
      const newCalories = prev.calories.active + addedCal;

      // Trigger celebration if crossed 10k steps!
      if (prev.steps.current < 10000 && newSteps >= 10000) {
        confetti({
          particleCount: 120,
          spread: 70,
          origin: { y: 0.6 }
        });
        showToast("🎉 Daily Step Goal (10,000 steps) Achieved!", "success");
      }

      return {
        ...prev,
        steps: {
          ...prev.steps,
          current: newSteps,
          distanceKm: newDistance,
        },
        calories: {
          ...prev.calories,
          active: newCalories,
        }
      };
    });
  };

  // Log hydration
  const logHydration = (amountMl = 250) => {
    setMetrics((prev) => {
      const newAmount = Math.min(4000, prev.hydration.currentMl + amountMl);
      if (prev.hydration.currentMl < prev.hydration.targetMl && newAmount >= prev.hydration.targetMl) {
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.7 }
        });
        showToast("💧 Daily Hydration Target Reached!", "success");
      }
      return {
        ...prev,
        hydration: {
          ...prev.hydration,
          currentMl: newAmount,
        }
      };
    });
    showToast(`Logged +${amountMl}ml of water`, "info");
  };

  // Toggle Find Band buzzer
  const triggerFindBand = () => {
    setDevice((prev) => ({ ...prev, findBandActive: true }));
    showToast("🔔 Band is vibrating and sounding alarm: 'BEEP - BEEP - BEEP'", "warning");

    // Audio chime simulation using Web Audio API if available
    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const playBeep = (time, freq) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, time);
        gain.gain.setValueAtTime(0.15, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.25);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(time);
        osc.stop(time + 0.25);
      };
      const now = audioCtx.currentTime;
      playBeep(now, 880);
      playBeep(now + 0.35, 1100);
      playBeep(now + 0.7, 1320);
    } catch (e) {
      // Audio context might be restricted before interaction
    }

    setTimeout(() => {
      setDevice((prev) => ({ ...prev, findBandActive: false }));
    }, 4000);
  };

  // Toggle DND
  const toggleDnd = () => {
    setDevice((prev) => {
      const nextState = !prev.dndActive;
      showToast(nextState ? "Do Not Disturb Enabled on Band" : "Do Not Disturb Disabled", "info");
      return { ...prev, dndActive: nextState };
    });
  };

  // Toggle Water Lock
  const toggleWaterLock = () => {
    setDevice((prev) => {
      const nextState = !prev.waterLock;
      showToast(nextState ? "Water Lock Engaged. Touchscreen locked." : "Water Ejected! Screen unlocked.", "info");
      return { ...prev, waterLock: nextState };
    });
  };

  // Change Active Watch Face
  const selectWatchFace = (faceId) => {
    setWatchFaces((prev) =>
      prev.map((f) => ({ ...f, active: f.id === faceId }))
    );
    showToast(`Transferred watch face to band successfully!`, "success");
  };

  // Workout Session Handlers
  const startWorkout = (workout) => {
    setActiveWorkout({
      ...workout,
      elapsedSeconds: 0,
      activeCalories: 0,
      distanceKm: 0,
      heartRate: 118,
      isPaused: false,
      startedAt: new Date(),
    });
    showToast(`Started ${workout.name} workout on Band`, "success");
  };

  const pauseWorkout = () => {
    setActiveWorkout((prev) => (prev ? { ...prev, isPaused: !prev.isPaused } : null));
  };

  const finishWorkout = () => {
    if (!activeWorkout) return;
    const burned = Math.round(activeWorkout.activeCalories);
    setMetrics((prev) => ({
      ...prev,
      calories: { ...prev.calories, active: prev.calories.active + burned },
      activeTime: { ...prev.activeTime, current: prev.activeTime.current + Math.ceil(activeWorkout.elapsedSeconds / 60) },
    }));
    showToast(`Workout Completed! Burned ${burned} kcal. Recorded to Health log.`, "success");
    setActiveWorkout(null);
  };

  // Live ECG & Heartbeat streaming interval
  useEffect(() => {
    const hrInterval = setInterval(() => {
      setMetrics((prev) => {
        let baseHr = activeWorkout ? 135 : isSimulatingWalk ? 108 : 72;
        const variation = (Math.random() * 6 - 3);
        const nextHr = Math.round(Math.max(48, Math.min(185, baseHr + variation)));
        
        let zone = "Resting";
        if (nextHr >= 60 && nextHr <= 100) zone = "Warm Up";
        else if (nextHr > 100 && nextHr <= 130) zone = "Fat Burn";
        else if (nextHr > 130 && nextHr <= 155) zone = "Cardio";
        else if (nextHr > 155) zone = "Peak";

        return {
          ...prev,
          heartRate: {
            ...prev.heartRate,
            current: nextHr,
            currentZone: zone,
            max: Math.max(prev.heartRate.max, nextHr),
            min: Math.min(prev.heartRate.min, nextHr),
          }
        };
      });

      // Update ECG stream points
      setEcgPoints((prev) => {
        const nextVal = (Math.random() > 0.85)
          ? 70 + (Math.random() > 0.5 ? 40 : -25) // QRS spike
          : 70 + (Math.sin(Date.now() / 150) * 8);
        return [...prev.slice(1), nextVal];
      });
    }, 600);

    return () => clearInterval(hrInterval);
  }, [activeWorkout, isSimulatingWalk]);

  // Live Workout timer ticker
  useEffect(() => {
    if (!activeWorkout || activeWorkout.isPaused) return;

    const timer = setInterval(() => {
      setActiveWorkout((prev) => {
        if (!prev || prev.isPaused) return prev;
        const nextSec = prev.elapsedSeconds + 1;
        const calPerSec = 0.18; // approx 11 kcal / min
        return {
          ...prev,
          elapsedSeconds: nextSec,
          activeCalories: Number((prev.activeCalories + calPerSec).toFixed(1)),
          distanceKm: Number((prev.distanceKm + 0.003).toFixed(3)),
          heartRate: Math.floor(128 + Math.sin(nextSec * 0.1) * 12),
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activeWorkout]);

  // Walk simulation ticker
  useEffect(() => {
    if (!isSimulatingWalk) return;
    const simInterval = setInterval(() => {
      addSteps(12);
    }, 800);
    return () => clearInterval(simInterval);
  }, [isSimulatingWalk]);

  const value = {
    device,
    metrics,
    hourlySteps,
    watchFaces,
    activeWorkout,
    activeTab,
    notificationToast,
    isSimulatingWalk,
    ecgPoints,
    setActiveTab,
    syncBand,
    addSteps,
    logHydration,
    triggerFindBand,
    toggleDnd,
    toggleWaterLock,
    selectWatchFace,
    startWorkout,
    pauseWorkout,
    finishWorkout,
    setIsSimulatingWalk,
    setNotificationToast,
    showToast,
  };

  return (
    <FitnessContext.Provider value={value}>
      {children}
    </FitnessContext.Provider>
  );
};

export const useFitness = () => {
  const context = useContext(FitnessContext);
  if (!context) {
    throw new Error('useFitness must be used within a FitnessProvider');
  }
  return context;
};
