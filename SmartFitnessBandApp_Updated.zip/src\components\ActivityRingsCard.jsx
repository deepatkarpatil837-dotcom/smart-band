import React from 'react';
import { useFitness } from '../context/FitnessContext';
import { Footprints, Flame, Timer, Trophy, TrendingUp, Plus } from 'lucide-react';

export const ActivityRingsCard = () => {
  const { metrics, hourlySteps, addSteps } = useFitness();

  const stepPct = Math.min(100, Math.round((metrics.steps.current / metrics.steps.target) * 100));
  const calPct = Math.min(100, Math.round((metrics.calories.active / metrics.calories.target) * 100));
  const timePct = Math.min(100, Math.round((metrics.activeTime.current / metrics.activeTime.target) * 100));

  // Circular calculations
  const calRadius = 78;
  const stepRadius = 58;
  const timeRadius = 38;

  const calCircumference = 2 * Math.PI * calRadius;
  const stepCircumference = 2 * Math.PI * stepRadius;
  const timeCircumference = 2 * Math.PI * timeRadius;

  const calOffset = calCircumference - (calPct / 100) * calCircumference;
  const stepOffset = stepCircumference - (stepPct / 100) * stepCircumference;
  const timeOffset = timeCircumference - (timePct / 100) * timeCircumference;

  const maxHourlySteps = Math.max(...hourlySteps.map(h => h.steps), 1000);

  return (
    <div className="glass-card rounded-2xl p-6 shadow-md">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-6">
        <div>
          <div className="flex items-center space-x-2">
            <h3 className="text-base font-black text-black">Daily Activity Rings</h3>
            <span className="bg-emerald-100 text-black text-xs px-2.5 py-0.5 rounded-full border border-emerald-400 font-extrabold">
              Today's Goals
            </span>
          </div>
          <p className="text-xs text-black/80 font-medium mt-0.5">Live sensor calculations from wrist accelerometer</p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => addSteps(250)}
            className="flex items-center space-x-1 px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-black border border-emerald-400 rounded-xl text-xs font-black transition-all active:scale-95 shadow-sm"
            title="Simulate 250 steps"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+250 Steps</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        
        {/* Triple Ring SVG Visual */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center relative">
          <div className="relative w-52 h-52 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
              {/* Calories Ring (Outer - Rose) */}
              <circle
                cx="100"
                cy="100"
                r={calRadius}
                fill="transparent"
                stroke="rgba(244, 63, 94, 0.12)"
                strokeWidth="14"
              />
              <circle
                cx="100"
                cy="100"
                r={calRadius}
                fill="transparent"
                stroke="#f43f5e"
                strokeWidth="14"
                strokeDasharray={calCircumference}
                strokeDashoffset={calOffset}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out ring-glow-rose"
              />

              {/* Steps Ring (Middle - Emerald) */}
              <circle
                cx="100"
                cy="100"
                r={stepRadius}
                fill="transparent"
                stroke="rgba(16, 185, 129, 0.12)"
                strokeWidth="14"
              />
              <circle
                cx="100"
                cy="100"
                r={stepRadius}
                fill="transparent"
                stroke="#10b981"
                strokeWidth="14"
                strokeDasharray={stepCircumference}
                strokeDashoffset={stepOffset}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out ring-glow-emerald"
              />

              {/* Active Time Ring (Inner - Cyan) */}
              <circle
                cx="100"
                cy="100"
                r={timeRadius}
                fill="transparent"
                stroke="rgba(6, 182, 212, 0.12)"
                strokeWidth="14"
              />
              <circle
                cx="100"
                cy="100"
                r={timeRadius}
                fill="transparent"
                stroke="#06b6d4"
                strokeWidth="14"
                strokeDasharray={timeCircumference}
                strokeDashoffset={timeOffset}
                strokeLinecap="round"
                className="transition-all duration-700 ease-out ring-glow-cyan"
              />
            </svg>

            {/* Centered Step Icon or Percentage */}
            <div className="absolute flex flex-col items-center justify-center text-center">
              <Footprints className="w-5 h-5 text-emerald-700 mb-0.5" />
              <span className="text-xl font-black text-black tracking-tight">{stepPct}%</span>
            </div>
          </div>
          
          <div className="text-center mt-2 text-sm font-black">Steps Done</div>

          <div className="flex items-center justify-center gap-4 mt-4 text-xs font-black">
            <span className="flex items-center gap-1.5 text-rose-700">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 ring-glow-rose"></span> Move ({calPct}%)
            </span>
            <span className="flex items-center gap-1.5 text-emerald-800">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-glow-emerald"></span> Steps ({stepPct}%)
            </span>
            <span className="flex items-center gap-1.5 text-cyan-800">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 ring-glow-cyan"></span> Exercise ({timePct}%)
            </span>
          </div>
        </div>

        {/* Metric Cards Breakdown */}
        <div className="lg:col-span-7 space-y-4">
          
                    {/* Active Calories Row */}
          <div className="bg-white/95 p-4 rounded-xl border border-amber-900/10 hover:border-rose-500/40 transition-all shadow-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-rose-50 text-rose-700 rounded-xl border border-rose-200">
                  <Flame className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-xl font-black text-black">{metrics.calories.active}</span>
                    <span className="text-xs text-black/80 font-bold">/ {metrics.calories.target} kcal</span>
                  </div>
                  <p className="text-xs text-black/80 font-medium mt-0.5">
                    Resting burn: <strong className="text-black font-extrabold">{metrics.calories.resting} kcal</strong> • Total: <strong className="text-black font-extrabold">{metrics.calories.active + metrics.calories.resting} kcal</strong>
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-sm font-black text-rose-700">{calPct}%</span>
                <p className="text-[10px] text-black font-bold">{metrics.calories.target - metrics.calories.active > 0 ? `${metrics.calories.target - metrics.calories.active} kcal left` : 'Completed'}</p>
              </div>
            </div>

            <div className="w-full bg-slate-200 h-2.5 rounded-full mt-3 overflow-hidden border border-slate-300">
              <div
                className="bg-rose-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${calPct}%` }}
              ></div>
            </div>
          </div>

          {/* Active Exercise Time */}
          <div className="bg-white/95 p-4 rounded-xl border border-amber-900/10 hover:border-cyan-500/40 transition-all shadow-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-cyan-50 text-cyan-700 rounded-xl border border-cyan-200">
                  <Timer className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-xl font-black text-black">{metrics.activeTime.current}</span>
                    <span className="text-xs text-black/80 font-bold">/ {metrics.activeTime.target} mins</span>
                  </div>
                  <p className="text-xs text-black/80 font-medium mt-0.5">
                    Intense movement & workout duration
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-sm font-black text-cyan-800">{timePct}%</span>
                <p className="text-[10px] text-black font-bold">{metrics.activeTime.target - metrics.activeTime.current > 0 ? `${metrics.activeTime.target - metrics.activeTime.current}m to go` : 'Done'}</p>
              </div>
            </div>

            <div className="w-full bg-slate-200 h-2.5 rounded-full mt-3 overflow-hidden border border-slate-300">
              <div
                className="bg-cyan-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${timePct}%` }}
              ></div>
            </div>
          </div>

          {/* Steps Progress Row */}
          <div className="bg-white/95 p-4 rounded-xl border border-amber-900/10 hover:border-emerald-500/40 transition-all shadow-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-200">
                  <Footprints className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-xl font-black text-black">{metrics.steps.current.toLocaleString()}</span>
                    <span className="text-xs text-black/80 font-bold">/ {metrics.steps.target.toLocaleString()} steps</span>
                  </div>
                  <div className="flex items-center space-x-3 text-xs text-black/80 font-medium mt-0.5">
                    <span>📏 <strong className="text-black font-extrabold">{metrics.steps.distanceKm} km</strong></span>
                    <span>•</span>
                    <span>🧗 <strong className="text-black font-extrabold">{metrics.steps.floors} floors</strong></span>
                    <span>•</span>
                    <span>⚡ Pace <strong className="text-black font-extrabold">{metrics.steps.paceMinPerKm}</strong></span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-sm font-black text-emerald-800">{stepPct}%</span>
                <p className="text-[10px] text-black font-bold">{(metrics.steps.target - metrics.steps.current > 0) ? `${(metrics.steps.target - metrics.steps.current).toLocaleString()} to goal` : 'Goal Met!'}</p>
              </div>
            </div>
            
            {/* Step Mini Bar */}
            <div className="w-full bg-slate-200 h-2.5 rounded-full mt-3 overflow-hidden border border-slate-300">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${stepPct}%` }}
              ></div>
            </div>
          </div>

        </div>

      </div>



    </div>
  );
};
