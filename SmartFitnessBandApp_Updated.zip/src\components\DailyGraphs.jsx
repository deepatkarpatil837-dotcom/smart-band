import React from 'react';
import { useFitness } from '../context/FitnessContext';
import { ArrowUpRight } from 'lucide-react';

export const DailyGraphs = () => {
  const { metrics, hourlySteps } = useFitness();

  // Get 9 hours of data to fit the UI design (e.g., 8 AM to 4 PM)
  const todayData = hourlySteps.slice(2, 11); 
  const labels = todayData.map(d => d.time.split(' ')[0]); // '8', '9', '10'...

  const maxSteps = Math.max(...todayData.map(d => d.steps), 1000);
  
  // Generate bar heights (percentages) based on the hourly steps
  const stepsData = todayData.map(d => Math.max(5, (d.steps / maxSteps) * 100));
  // Fake calories/time proportional to steps for visual effect (deterministic)
  const calsData = todayData.map((d, i) => Math.max(5, Math.min(100, (d.steps / maxSteps) * 100 * (0.8 + (i % 3) * 0.15))));
  const timeData = todayData.map((d, i) => Math.max(5, Math.min(100, (d.steps / maxSteps) * 100 * (0.6 + (i % 4) * 0.12))));

  const GraphCard = ({ title, value, subtitle, data, colorClass, shadowColor, glowColor }) => (
    <div className="bg-[#0a0a0a] rounded-2xl p-6 border border-white/5 relative overflow-hidden flex flex-col justify-between h-[300px] shadow-2xl">
      
      {/* Heavy bottom glow matching image */}
      <div className={`absolute -bottom-16 left-1/2 -translate-x-1/2 w-[120%] h-48 blur-[50px] opacity-40 pointer-events-none ${shadowColor}`}></div>

      <div className="relative z-10">
        <div className="flex items-center space-x-2 text-white/70 mb-2">
          <span className="text-xs font-semibold tracking-wide">{title}</span>
        </div>
        <div className="flex items-end space-x-3">
          <span className="text-4xl font-bold text-white tracking-tight">{value}</span>
          <span className={`text-sm font-bold flex items-center mb-1.5 ${colorClass}`}>
            <ArrowUpRight className="w-4 h-4 mr-0.5" />
            Today
          </span>
        </div>
        <p className="text-xs text-white/40 mt-1">{subtitle}</p>
      </div>

      <div className="mt-auto relative z-10">
        <div className="flex items-end justify-between h-32 mb-4 px-1">
          {data.map((val, idx) => (
            <div key={idx} className="flex flex-col items-center justify-end w-full h-full group">
              <div 
                className={`w-3 sm:w-4 rounded-full transition-all duration-700 ${colorClass.replace('text-', 'bg-')}`}
                style={{ 
                  height: `${val}%`, 
                  boxShadow: `0 0 20px ${glowColor}, 0 0 10px ${glowColor}, inset 0 0 5px rgba(255,255,255,0.8)`
                }}
              ></div>
            </div>
          ))}
        </div>
        <div className="flex justify-between text-[11px] font-mono text-white/50 px-2">
          {labels.map((lbl, idx) => (
            <span key={idx}>{lbl}</span>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-6">
      <GraphCard 
        title="Today's Steps" 
        value={metrics.steps.current.toLocaleString()} 
        subtitle={`Goal: ${metrics.steps.target.toLocaleString()}`}
        data={stepsData} 
        colorClass="text-emerald-400"
        shadowColor="bg-emerald-500"
        glowColor="rgba(52,211,153,0.8)"
      />
      <GraphCard 
        title="Today's Calories" 
        value={metrics.calories.active.toLocaleString()} 
        subtitle={`Goal: ${metrics.calories.target} kcal`}
        data={calsData} 
        colorClass="text-rose-500"
        shadowColor="bg-rose-600"
        glowColor="rgba(244,63,94,0.8)"
      />
      <GraphCard 
        title="Today's Active Time" 
        value={`${metrics.activeTime.current}m`} 
        subtitle={`Goal: ${metrics.activeTime.target}m`}
        data={timeData} 
        colorClass="text-purple-300"
        shadowColor="bg-purple-500"
        glowColor="rgba(192,132,252,0.8)"
      />
    </div>
  );
};
