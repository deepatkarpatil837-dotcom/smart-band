import React, { useRef, useEffect } from 'react';
import { useFitness } from '../context/FitnessContext';
import { Heart, Activity, Zap, Info } from 'lucide-react';

export const HeartRateCard = () => {
  const { metrics, ecgPoints } = useFitness();
  const canvasRef = useRef(null);

  // Draw real-time ECG oscilloscope canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // Subtle background grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    const gridSize = 16;
    for (let x = 0; x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Draw ECG path
    ctx.beginPath();
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.shadowColor = 'rgba(16, 185, 129, 0.6)';
    ctx.shadowBlur = 8;

    const stepX = width / (ecgPoints.length - 1);

    ecgPoints.forEach((val, index) => {
      // Normalize value to canvas height (center around height / 2)
      const y = (height / 2) - ((val - 70) * (height / 100));
      const x = index * stepX;
      if (index === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });

    ctx.stroke();

    // Draw leading glowing dot
    if (ecgPoints.length > 0) {
      const lastX = width;
      const lastVal = ecgPoints[ecgPoints.length - 1];
      const lastY = (height / 2) - ((lastVal - 70) * (height / 100));

      ctx.beginPath();
      ctx.arc(lastX - 2, lastY, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#34d399';
      ctx.fill();
    }
  }, [ecgPoints]);

  const hr = metrics.heartRate;

  // Color mapping based on zone
  const getZoneBadgeColor = (zone) => {
    switch (zone) {
      case 'Peak': return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
      case 'Cardio': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'Fat Burn': return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
      case 'Warm Up': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      default: return 'bg-slate-700/40 text-slate-300 border-slate-600';
    }
  };

  return (
    <div className="glass-card rounded-2xl p-6 shadow-md relative overflow-hidden">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <div className="p-2 bg-rose-50 text-rose-700 rounded-xl border border-rose-200">
            <Heart className="w-5 h-5 animate-pulse text-rose-600 fill-rose-500/30" />
          </div>
          <div>
            <h3 className="text-base font-black text-black">Heart Rate Telemetry</h3>
            <p className="text-xs text-black/80 font-medium">Continuous optical PPG sensor stream</p>
          </div>
        </div>

        <span className={`text-xs px-2.5 py-1 rounded-full border font-black shadow-xs ${getZoneBadgeColor(hr.currentZone)}`}>
          {hr.currentZone}
        </span>
      </div>

      {/* Main BPM Display & Real-time ECG Canvas */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center my-4">
        
        {/* BPM Number */}
        <div className="md:col-span-4 flex flex-col justify-center">
          <div className="flex items-baseline space-x-2">
            <span className="text-5xl font-black text-black tracking-tight">{hr.current}</span>
            <span className="text-sm font-black text-rose-700 uppercase tracking-wide">BPM</span>
          </div>
          <p className="text-xs text-black/80 font-medium mt-1 flex items-center gap-1">
            <Activity className="w-3.5 h-3.5 text-emerald-700" />
            Resting Rate: <strong className="text-black font-extrabold">{hr.resting} BPM</strong>
          </p>
        </div>

        {/* Live ECG Oscilloscope */}
        <div className="md:col-span-8 bg-[#0e141f] rounded-xl p-2 border border-slate-700/60 shadow-inner relative">
          <div className="absolute top-2 left-3 flex items-center space-x-1 text-[10px] text-emerald-400 font-mono font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span>LIVE PPG STREAM</span>
          </div>
          <canvas
            ref={canvasRef}
            width={340}
            height={80}
            className="w-full h-20 block"
          />
        </div>

      </div>

      {/* Min / Max / HRV Stats */}
      <div className="grid grid-cols-3 gap-3 py-3 border-y border-amber-900/10 text-center my-4">
        <div className="bg-white/95 p-2.5 rounded-xl border border-amber-900/10 shadow-xs">
          <span className="text-[10px] text-black font-bold uppercase">Min (24h)</span>
          <p className="text-sm font-black text-emerald-800 mt-0.5">{hr.min} <span className="text-[10px] text-black font-normal">bpm</span></p>
        </div>
        <div className="bg-white/95 p-2.5 rounded-xl border border-amber-900/10 shadow-xs">
          <span className="text-[10px] text-black font-bold uppercase">Max (24h)</span>
          <p className="text-sm font-black text-rose-700 mt-0.5">{hr.max} <span className="text-[10px] text-black font-normal">bpm</span></p>
        </div>
        <div className="bg-white/95 p-2.5 rounded-xl border border-amber-900/10 shadow-xs">
          <span className="text-[10px] text-black font-bold uppercase">HRV (Autonomic)</span>
          <p className="text-sm font-black text-cyan-800 mt-0.5">58 <span className="text-[10px] text-black font-normal">ms (Good)</span></p>
        </div>
      </div>

      {/* Heart Rate Zones Distribution Bar */}
      <div className="space-y-2 mt-4">
        <div className="flex items-center justify-between text-xs">
          <span className="font-black text-black">Zone Distribution (Today)</span>
          <span className="text-[11px] text-black/80 font-bold">Total: 632 active mins</span>
        </div>

        {/* Multi-segment Zone Bar */}
        <div className="w-full h-3 bg-slate-200 rounded-full flex overflow-hidden border border-slate-300">
          {hr.zones.map((zone, idx) => (
            <div
              key={idx}
              title={`${zone.name}: ${zone.minutes} mins (${zone.percentage}%)`}
              style={{ width: `${zone.percentage}%`, backgroundColor: zone.color }}
              className="h-full transition-all hover:opacity-80 cursor-pointer"
            ></div>
          ))}
        </div>

        {/* Zone Labels */}
        <div className="flex flex-wrap items-center justify-between text-[10px] text-black font-bold pt-1">
          {hr.zones.map((zone, idx) => (
            <div key={idx} className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: zone.color }}></span>
              <span>{zone.name.split(' ')[0]} ({zone.minutes}m)</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
