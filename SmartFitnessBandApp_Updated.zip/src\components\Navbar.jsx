import React from 'react';
import { useFitness } from '../context/FitnessContext';
import {
  Activity,
  BatteryCharging,
  BatteryMedium,
  Bluetooth,
  RefreshCw,
  Sliders,
  Flame,
  Heart,
  Watch,
  Sparkles,
  Bell
} from 'lucide-react';

export const Navbar = ({ onOpenSimulator }) => {
  const { device, syncBand, activeTab, setActiveTab, metrics } = useFitness();

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-[#FAF7F2]/90 border-b border-amber-900/10 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand & App Title */}
          <div className="flex items-center space-x-3">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 shadow-md shadow-emerald-500/20 text-black">
              <Activity className="w-6 h-6 stroke-[2.5]" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-extrabold tracking-tight text-black flex items-center gap-1.5">
                  FitPulse <span className="text-emerald-900 font-black text-xs px-1.5 py-0.5 rounded bg-emerald-100 border border-emerald-400">PRO</span>
                </h1>
              </div>
              <p className="text-xs text-black font-semibold hidden sm:block">Smart Band Companion Hub</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1 bg-[#EFE9DF] p-1 rounded-xl border border-amber-900/10">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
                activeTab === 'overview'
                  ? 'bg-white text-black shadow-sm shadow-black/5 font-black'
                  : 'text-black/80 hover:text-black hover:bg-white/50'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('notification')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-extrabold transition-all flex items-center gap-1.5 ${
                activeTab === 'notification'
                  ? 'bg-white text-black shadow-sm shadow-black/5 font-black'
                  : 'text-black/80 hover:text-black hover:bg-white/50'
              }`}
            >
              <Bell className="w-3.5 h-3.5" />
              Notification
            </button>
          </nav>

          {/* Quick Band Status & Actions */}
          <div className="flex items-center space-x-3">
            
            {/* Band Connection Pill */}
            <div className="hidden lg:flex items-center space-x-2 bg-white/90 px-3 py-1.5 rounded-full border border-amber-900/10 text-xs shadow-sm">
              <span className="flex items-center text-emerald-800 font-bold">
                <Bluetooth className="w-3.5 h-3.5 mr-1" />
                Connected
              </span>

            </div>

            {/* Sync Now Button */}
            <button
              onClick={syncBand}
              disabled={device.isSyncing}
              title="Sync Band Telemetry"
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 text-black rounded-xl border border-amber-900/15 text-xs font-bold transition-all active:scale-95 shadow-sm disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-emerald-700 ${device.isSyncing ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">{device.isSyncing ? 'Syncing...' : 'Sync'}</span>
            </button>

            {/* Band Simulator Button */}
            <button
              onClick={onOpenSimulator}
              className="flex items-center space-x-1 px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-black border border-purple-300 rounded-xl text-xs font-extrabold transition-all active:scale-95 shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-700" />
              <span>Simulator</span>
            </button>

            {/* Streak indicator */}
            <div className="flex items-center space-x-1 bg-amber-100 border border-amber-300 px-2.5 py-1.5 rounded-xl text-black text-xs font-extrabold shadow-sm">
              <span>🔥</span>
              <span>{metrics.streak.days}d</span>
            </div>

          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-amber-900/10">
          <button
            onClick={() => setActiveTab('overview')}
            className={`text-xs px-2 py-1 rounded ${activeTab === 'overview' ? 'text-black font-black underline' : 'text-black/80 font-bold'}`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('notification')}
            className={`text-xs px-2 py-1 rounded ${activeTab === 'notification' ? 'text-black font-black underline' : 'text-black/80 font-bold'}`}
          >
            Notification
          </button>
        </div>
      </div>
    </header>
  );
};
