export const initialFitnessState = {
  device: {
    name: "FitPulse Ultra Band 5",
    model: "FP-B5-PRO",
    firmware: "v3.2.8",
    batteryLevel: 82,
    isCharging: false,
    isConnected: true,
    isSyncing: false,
    lastSynced: "Just now",
    bluetoothRssi: -58, // dBm (Strong signal)
    findBandActive: false,
    dndActive: false,
    waterLock: false,
  },
  metrics: {
    steps: {
      current: 8420,
      target: 10000,
      distanceKm: 6.32,
      floors: 14,
      paceMinPerKm: "5'42\"",
    },
    calories: {
      active: 640,
      resting: 1480,
      target: 750,
    },
    activeTime: {
      current: 48,
      target: 60, // minutes
    },
    heartRate: {
      current: 74,
      resting: 61,
      min: 52,
      max: 146,
      currentZone: "Fat Burn", // Resting, Warm Up, Fat Burn, Cardio, Peak
      zones: [
        { name: "Resting (<60)", minutes: 240, percentage: 38, color: "#94a3b8" },
        { name: "Warm Up (60-100)", minutes: 280, percentage: 44, color: "#10b981" },
        { name: "Fat Burn (101-130)", minutes: 65, percentage: 10, color: "#eab308" },
        { name: "Cardio (131-155)", minutes: 35, percentage: 6, color: "#f97316" },
        { name: "Peak (>155)", minutes: 12, percentage: 2, color: "#ef4444" },
      ]
    },
    sleep: {
      score: 89,
      rating: "Optimal Recovery",
      totalHours: 7.8,
      sleepTime: "11:15 PM",
      wakeTime: "07:03 AM",
      stages: [
        { name: "Deep Sleep", duration: "2h 14m", percent: 29, color: "#6366f1" },
        { name: "REM Sleep", duration: "1h 52m", percent: 24, color: "#8b5cf6" },
        { name: "Light Sleep", duration: "3h 22m", percent: 43, color: "#38bdf8" },
        { name: "Awake", duration: "20m", percent: 4, color: "#f43f5e" }
      ],
      efficiency: "94%",
      restingHrDuringSleep: 54,
    },
    spo2: {
      current: 98,
      status: "Normal",
      min24h: 96,
      max24h: 99,
    },
    stress: {
      current: 28,
      level: "Relaxed", // Relaxed (1-29), Low (30-59), Medium (60-79), High (80-100)
      trend: "Trending Down",
    },
    bodyTemp: {
      current: 36.6,
      deviation: "+0.1°C",
      status: "Normal Baseline",
    },
    hydration: {
      currentMl: 1750,
      targetMl: 2500,
    },
    streak: {
      days: 14,
      bestStreak: 21,
    }
  },
  hourlySteps: [
    { time: "6 AM", steps: 120 },
    { time: "7 AM", steps: 850 },
    { time: "8 AM", steps: 1420 },
    { time: "9 AM", steps: 680 },
    { time: "10 AM", steps: 430 },
    { time: "11 AM", steps: 520 },
    { time: "12 PM", steps: 1100 },
    { time: "1 PM", steps: 890 },
    { time: "2 PM", steps: 410 },
    { time: "3 PM", steps: 760 },
    { time: "4 PM", steps: 1240 },
    { time: "5 PM", steps: 0 },
    { time: "6 PM", steps: 0 },
  ],
  weeklyHistory: [
    { day: "Mon", steps: 10420, calories: 720, sleepHours: 7.5, goalMet: true },
    { day: "Tue", steps: 8900, calories: 610, sleepHours: 6.8, goalMet: false },
    { day: "Wed", steps: 11250, calories: 810, sleepHours: 8.1, goalMet: true },
    { day: "Thu", steps: 9800, calories: 690, sleepHours: 7.2, goalMet: false },
    { day: "Fri", steps: 12400, calories: 890, sleepHours: 7.9, goalMet: true },
    { day: "Sat", steps: 14100, calories: 950, sleepHours: 8.4, goalMet: true },
    { day: "Sun (Today)", steps: 8420, calories: 640, sleepHours: 7.8, goalMet: false },
  ],
  workouts: [
    { id: "my-activity", name: "My Activity", icon: "Activity", color: "from-emerald-500 to-teal-600", bgGlow: "rgba(16, 185, 129, 0.2)", avgPace: "Active", calRate: "Status" },
  ],
  aiInsights: [
    {
      id: 1,
      type: "recovery",
      tag: "OPTIMAL RECOVERY",
      title: "Prime condition for high-intensity training",
      description: "Your sleep score (89) and resting heart rate (61 bpm) indicate 96% physical recovery. You are primed for peak cardio or strength gains today.",
      time: "8:00 AM",
      accent: "emerald"
    },
    {
      id: 2,
      type: "pacing",
      tag: "STEP TARGET",
      title: "1,580 steps to 10k daily milestone",
      description: "A quick 15-minute evening stroll will complete today's step goal and keep your 14-day streak alive!",
      time: "2:30 PM",
      accent: "cyan"
    },
    {
      id: 3,
      type: "hydration",
      tag: "HYDRATION",
      title: "750ml needed to hit hydration goal",
      description: "You've logged 1,750ml so far. Drink 3 glasses before 9 PM to maintain optimum cellular recovery.",
      time: "4:00 PM",
      accent: "blue"
    }
  ],
  watchFaces: [
    { id: "neon-pulse", name: "Neon Pulse", style: "Futuristic Glow", previewColor: "#10b981", active: true },
    { id: "chrono-metric", name: "Chrono Metric", style: "Minimal Triple Rings", previewColor: "#f43f5e", active: false },
    { id: "cyber-orbit", name: "Cyber Orbit", style: "Sci-Fi Telemetry", previewColor: "#06b6d4", active: false },
    { id: "zen-gradient", name: "Zen Horizon", style: "Clean Aura Gradient", previewColor: "#a855f7", active: false },
  ]
};
