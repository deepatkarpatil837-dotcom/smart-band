import React from 'react';
import { useFitness } from '../context/FitnessContext';
import {
  Sparkles,
  X,
  Footprints,
  Heart,
  BatteryCharging,
  BatteryWarning,
  Bell,
  RotateCw,
  Zap,
  Play,
  Pause,
  Sliders
} from 'lucide-react';

export const BandSimulatorModal = ({ isOpen, onClose }) => {
  const {
    metrics,
    device,
    addSteps,
    syncBand,
    isSimulatingWalk,
    setIsSimulatingWalk,
    showToast
  } = useFitness();

  if (!isOpen) return null;

  const simulateIncomingBandNotification = () => {
    showToast("📩 Band Notification: 'Sarah: Hey! Ready for our evening run?'", "info");
  };

  const simulateLowBattery = () => {
    showToast("⚠️ Low Battery Alert: FitPulse Band is at 14%. Please connect to magnetic charger.", "warning");
  };

  const simulateHeartRateSpike = () => {
    showToast("💓 Heart Rate Alert: Elevated HR detected (148 BPM - Cardio zone).", "warning");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
      <div className="bg-white border border-purple-300 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl relative overflow-hidden text-black">
        
        {/* Glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-purple-200/40 rounded-full blur-3xl pointer-events-none"></div>

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-900/10">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-purple-100 text-purple-700 rounded-xl border border-purple-300">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-black">Smart Band Telemetry Simulator</h3>
              <p className="text-xs text-black/80 font-medium">Simulate wrist hardware sensor inputs in real-time</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-black/60 hover:text-black p-1 rounded-lg hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Interactive Controls */}
        <div className="space-y-4 my-6">
          
          {/* Continuous Walk Generator */}
          <div className="bg-[#FAF7F2] p-4 rounded-2xl border border-amber-900/10 flex items-center justify-between shadow-xs">
            <div className="flex items-center space-x-3">
              <div className={`p-2.5 rounded-xl ${isSimulatingWalk ? 'bg-emerald-100 text-emerald-700 animate-bounce' : 'bg-slate-200 text-black'}`}>
                <Footprints className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-black text-black">Live Walk Motion Simulator</h4>
                <p className="text-[11px] text-black/80 font-medium">Continuously streams +12 steps every 800ms</p>
              </div>
            </div>
            <button
              onClick={() => setIsSimulatingWalk(!isSimulatingWalk)}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center space-x-1.5 ${
                isSimulatingWalk
                  ? 'bg-amber-400 text-black shadow-md shadow-amber-500/20'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20'
              }`}
            >
              {isSimulatingWalk ? (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  <span>Stop Walk</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Start Walking</span>
                </>
              )}
            </button>
          </div>

          {/* Quick Step Burst Injection */}
          <div className="bg-[#FAF7F2] p-4 rounded-2xl border border-amber-900/10 shadow-xs">
            <h4 className="text-xs font-black text-black mb-2">Inject Accelerometer Step Bursts</h4>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => addSteps(250)}
                className="py-2 bg-white hover:bg-emerald-50 text-black border border-emerald-400 rounded-xl text-xs font-black active:scale-95 transition-all shadow-xs"
              >
                +250 Steps
              </button>
              <button
                onClick={() => addSteps(500)}
                className="py-2 bg-white hover:bg-emerald-50 text-black border border-emerald-400 rounded-xl text-xs font-black active:scale-95 transition-all shadow-xs"
              >
                +500 Steps
              </button>
              <button
                onClick={() => addSteps(1500)}
                className="py-2 bg-white hover:bg-emerald-50 text-black border border-emerald-400 rounded-xl text-xs font-black active:scale-95 transition-all shadow-xs"
              >
                +1,500 Steps
              </button>
            </div>
          </div>

          {/* Hardware Trigger Simulations */}
          <div className="bg-[#FAF7F2] p-4 rounded-2xl border border-amber-900/10 shadow-xs">
            <h4 className="text-xs font-black text-black mb-2">Simulate Band Hardware Events</h4>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={simulateIncomingBandNotification}
                className="py-2.5 px-3 bg-white hover:bg-slate-50 text-black border border-amber-900/15 rounded-xl text-xs font-black flex items-center justify-center space-x-1.5 active:scale-95 transition-all shadow-xs"
              >
                <Bell className="w-3.5 h-3.5 text-cyan-700" />
                <span>Band Notification</span>
              </button>
              <button
                onClick={simulateHeartRateSpike}
                className="py-2.5 px-3 bg-white hover:bg-slate-50 text-black border border-amber-900/15 rounded-xl text-xs font-black flex items-center justify-center space-x-1.5 active:scale-95 transition-all shadow-xs"
              >
                <Heart className="w-3.5 h-3.5 text-rose-600" />
                <span>Cardio Spike</span>
              </button>
              <button
                onClick={simulateLowBattery}
                className="py-2.5 px-3 bg-white hover:bg-slate-50 text-black border border-amber-900/15 rounded-xl text-xs font-black flex items-center justify-center space-x-1.5 active:scale-95 transition-all shadow-xs"
              >
                <BatteryWarning className="w-3.5 h-3.5 text-amber-600" />
                <span>Low Battery Alert</span>
              </button>
              <button
                onClick={syncBand}
                className="py-2.5 px-3 bg-white hover:bg-slate-50 text-black border border-amber-900/15 rounded-xl text-xs font-black flex items-center justify-center space-x-1.5 active:scale-95 transition-all shadow-xs"
              >
                <RotateCw className="w-3.5 h-3.5 text-emerald-700" />
                <span>Trigger Sync</span>
              </button>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-purple-600/30"
          >
            Close Simulator
          </button>
        </div>

      </div>
    </div>
  );
};
