import React, { useState } from 'react';
import { FitnessProvider, useFitness } from './context/FitnessContext';
import { Navbar } from './components/Navbar';
import { DeviceStatusCard } from './components/DeviceStatusCard';
import { ActivityRingsCard } from './components/ActivityRingsCard';
import { HeartRateCard } from './components/HeartRateCard';
import { SleepAnalysisCard } from './components/SleepAnalysisCard';
import { VitalCards } from './components/VitalCards';
import { WorkoutLauncher } from './components/WorkoutLauncher';
import { AiCoachCard } from './components/AiCoachCard';
import { WatchFaceGallery } from './components/WatchFaceGallery';
import { BandSimulatorModal } from './components/BandSimulatorModal';
import { DailyGraphs } from './components/DailyGraphs';
import {
  Bell,
  CheckCircle2,
  AlertTriangle,
  Info,
  Radio,
  Heart,
  Flame,
  Watch,
  Activity,
  Layers
} from 'lucide-react';

const DashboardContent = () => {
  const { activeTab, notificationToast } = useFitness();
  const [simulatorOpen, setSimulatorOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-black flex flex-col justify-between selection:bg-emerald-500 selection:text-white">
      
      {/* Toast Notification Banner */}
      {notificationToast && (
        <div className="fixed top-20 right-4 z-50 animate-bounce max-w-md">
          <div className={`p-4 rounded-2xl shadow-xl border flex items-center space-x-3 backdrop-blur-xl ${
            notificationToast.type === 'success'
              ? 'bg-emerald-50/95 border-emerald-300 text-black shadow-emerald-500/10'
              : notificationToast.type === 'warning'
              ? 'bg-amber-50/95 border-amber-300 text-black shadow-amber-500/10'
              : 'bg-white/95 border-amber-900/15 text-black shadow-black/5'
          }`}>
            {notificationToast.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />}
            {notificationToast.type === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />}
            {notificationToast.type === 'info' && <Info className="w-5 h-5 text-cyan-600 flex-shrink-0" />}
            {notificationToast.type === 'sync' && <Radio className="w-5 h-5 text-emerald-600 flex-shrink-0 animate-spin" />}
            <span className="text-xs font-bold leading-snug">{notificationToast.message}</span>
          </div>
        </div>
      )}

      {/* Main App Container */}
      <div>
        <Navbar onOpenSimulator={() => setSimulatorOpen(true)} />

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
          
          {/* Always show device status card */}
          <DeviceStatusCard />

          {/* TAB 1: OVERVIEW (Comprehensive Home Page) */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Daily Activity Rings & Steps */}
              <ActivityRingsCard />

              {/* Daily Dark Theme Graphs */}
              <DailyGraphs />

              {/* Vitals Summary Grid */}
              <VitalCards />

              {/* Quick Workout Launcher */}
              <WorkoutLauncher />

              {/* Heart Rate ECG & Sleep Recovery */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <HeartRateCard />
                <SleepAnalysisCard />
              </div>

              {/* AI Health Coach & History */}
              <AiCoachCard />
            </div>
          )}

          {/* TAB 2: NOTIFICATIONS */}
          {activeTab === 'notification' && (
            <div className="space-y-6">
              <div className="glass-card-interactive rounded-2xl p-8 text-center text-black shadow-sm">
                <Bell className="w-8 h-8 mx-auto mb-4 text-emerald-600" />
                <h3 className="text-xl font-black mb-2">Notifications</h3>
                <p className="text-black/70 font-medium">Your notifications will appear here.</p>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* Simulator Modal */}
      <BandSimulatorModal
        isOpen={simulatorOpen}
        onClose={() => setSimulatorOpen(false)}
      />

      {/* Footer */}
      <footer className="mt-16 border-t border-amber-900/10 bg-[#F3EFE8] py-6 text-center text-xs text-black">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span className="font-bold text-black">FitPulse Companion Hub • Bluetooth LE 5.3 Active</span>
          </div>
          <p className="text-black font-medium">
            Smart Band Companion Dashboard • Designed for 24/7 Health Monitoring
          </p>
          <div className="flex items-center space-x-3 text-black font-mono text-[11px] font-semibold">
            <span>Sensors: PPG + 6-Axis IMU + SpO2 + Temp</span>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default function App() {
  return (
    <FitnessProvider>
      <DashboardContent />
    </FitnessProvider>
  );
}
