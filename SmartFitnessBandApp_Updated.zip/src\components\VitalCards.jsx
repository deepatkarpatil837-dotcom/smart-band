import React, { useState, useEffect } from 'react';
import { useFitness } from '../context/FitnessContext';
import {
  Wind,
  Droplets,
  Thermometer,
  Activity,
  Plus,
  Play,
  Pause,
  X,
  Sparkles,
  HeartPulse
} from 'lucide-react';

export const VitalCards = () => {
  const { metrics, logHydration } = useFitness();
  const hydrationPct = Math.min(100, Math.round((metrics.hydration.currentMl / metrics.hydration.targetMl) * 100));

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* 1. Blood Oxygen (SpO2) */}
        <div className="glass-card-interactive rounded-2xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-black uppercase text-black">Blood Oxygen (SpO2)</span>
              <div className="p-2 bg-sky-50 text-sky-700 rounded-xl border border-sky-200">
                <Wind className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-black text-black">{metrics.spo2.current}%</span>
              <span className="text-xs font-black text-emerald-800">Optimal</span>
            </div>
            <p className="text-xs text-black/80 font-medium mt-2">
              24h Range: <strong className="text-black font-black">{metrics.spo2.min24h}% - {metrics.spo2.max24h}%</strong>
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-amber-900/10 flex items-center justify-between text-[11px] text-black font-bold">
            <span>Red LED Reflected Sensor</span>
            <span className="text-emerald-850 font-black">99.2% accuracy</span>
          </div>
        </div>


        {/* 3. Skin Temperature & Readiness */}
        <div className="glass-card-interactive rounded-2xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-black uppercase text-black">Skin Temp (Wrist)</span>
              <div className="p-2 bg-amber-50 text-amber-700 rounded-xl border border-amber-200">
                <Thermometer className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-black text-black">{metrics.bodyTemp.current}°C</span>
              <span className="text-xs font-bold text-black/80">({metrics.bodyTemp.deviation})</span>
            </div>
            <p className="text-xs text-black/80 font-medium mt-2">
              Status: <strong className="text-emerald-800 font-black">{metrics.bodyTemp.status}</strong>
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-amber-900/10 flex items-center justify-between text-[11px] text-black font-bold">
            <span>Thermistor Sensor</span>
            <span className="text-black font-extrabold">Within baseline</span>
          </div>
        </div>

        {/* 4. Hydration Quick Logger */}
        <div className="glass-card-interactive rounded-2xl p-5 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-black uppercase text-black">Daily Hydration</span>
              <div className="p-2 bg-blue-50 text-blue-700 rounded-xl border border-blue-200">
                <Droplets className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-2xl font-black text-black">
                {hydrationPct >= 100 ? 'Hydrated' : hydrationPct >= 50 ? 'Normal' : 'Dehydrated'}
              </span>
            </div>

            {/* Hydration progress bar */}
            <div className="w-full bg-slate-200 h-2.5 rounded-full mt-3 overflow-hidden border border-slate-300">
              <div
                className="bg-blue-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${hydrationPct}%` }}
              ></div>
            </div>
          </div>

          {/* Quick Add Water Buttons */}
          <div className="grid grid-cols-2 gap-2 mt-4">
            <button
              onClick={() => logHydration(250)}
              className="py-1.5 px-2 bg-blue-50 hover:bg-blue-100 text-black border border-blue-300 rounded-xl text-xs font-black flex items-center justify-center space-x-1 active:scale-95 transition-all shadow-xs"
            >
              <Plus className="w-3 h-3 text-blue-700" />
              <span>+250ml</span>
            </button>
            <button
              onClick={() => logHydration(500)}
              className="py-1.5 px-2 bg-blue-50 hover:bg-blue-100 text-black border border-blue-300 rounded-xl text-xs font-black flex items-center justify-center space-x-1 active:scale-95 transition-all shadow-xs"
            >
              <Plus className="w-3 h-3 text-blue-700" />
              <span>+500ml</span>
            </button>
          </div>
        </div>

      </div>


    </>
  );
};
